Instructions for using Artistic Style Wx are included in the *doc* directory.

The file **install.html**' contains instructions for compiling and
installing Artistic Style Wx.

There is currently no documentation for using AStyleWx. But the GUI is
user friendly.
